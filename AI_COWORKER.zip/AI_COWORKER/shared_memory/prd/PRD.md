# Product Requirement Document (PRD): Adorini (v1.1 MVP)

> **Owner**: `@PM` (Product Manager)
> **Status**: FINALIZED & APPROVED
> **Target Audience**: Women aged 25–55, sizes 40–48, price band ₹300–1,500
> **Theme Palette**: Peach (`#FFDAB9`), Light Brown (`#C4A484`)

---

## Key Modules & Specifications

### 1. Auth & Account (`@PM-MODULE-01`)
- Phone OTP sign up/login via MSG91 + Google OAuth 2.0.
- Mandatory initial profile setup (first name, last name, phone, email, gender, full delivery address with PIN, city, state).
- Persistent JWT sessions across app opens.

### 2. Catalog & Discovery (`@PM-MODULE-02`)
- Garment type tabs: Kurti, Two piece, Three piece, Blouse, Petticoat.
- Print/technique filters: Plain, Kalankari, Ajrak, Batik, Aplik, Fancy.
- Search suggestions as you type (2+ letters).
- Filters: Price bands, Size (40-48), Favorites, Brand rail (sana, mg, mm, NAVRANGA).
- Infinite scroll (20 items per page).

### 3. Product Detail Page (PDP) & Trust (`@PM-MODULE-03`)
- Up to 5 media assets gallery (video + image viewer).
- Fabric-specific size guidance (Stretch vs. Rigid rules).
- Out-of-range size option: "Enquire for custom size" form.
- Review list with fit-accuracy tag (`runs small` / `true to size` / `runs large`).
- Official media badge for admin-curated media.

### 4. Cart & COD Checkout (`@PM-MODULE-04`)
- Inline cart editor (size, color, quantity).
- Cashfree payment gateway integration (COD, UPI, Card).
- COD order OTP confirmation modal via MSG91 before dispatch.
- Delivery address editable anytime before status becomes `Shipped`.

### 5. Orders & Post-Purchase (`@PM-MODULE-05`)
- Filterable order list by status (`Ordered`, `Pending_Verification`, `Confirmed`, `Shipped`, `Delivered`, `Cancelled`, `Returned`).
- Live tracking status timeline via Delhivery API.
- 3-day post-delivery return request flow.
- "Buy again" one-tap reorder.

### 6. Growth & Retention (`@PM-MODULE-06`)
- Free delivery on orders > ₹3,000 (auto-applied).
- Referral bonus: Referrer earns ₹100 credit on first **delivered** order.
- First order discount: 10% off (auto-applied).
