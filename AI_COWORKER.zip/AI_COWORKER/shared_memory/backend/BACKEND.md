# Backend Build Log

> **Owner**: `@BE` (API Architect)
> **Status**: IN PROGRESS — Phase 1 of 4 complete
> **Last updated**: 2026-08-10
> **Detailed tracking**: `Adorini_Backend/.gsd/` (SPEC, ROADMAP, STATE, DECISIONS)

---

## 1. Runtime Environment (Verified)

| Item | Value |
| :--- | :--- |
| Node.js | 24.12.0 (Active LTS) — pinned via `.nvmrc` + `engines.node >=24.0.0` |
| npm | 11.6.2 |
| NestJS | 11.1.x |
| TypeScript | 5.7.x, `strict: true`, `noImplicitAny`, `noUnusedLocals`, `noImplicitReturns` |
| Validation | Zod v4 + `nestjs-zod` 5.5.0 |

---

## 2. Modules Delivered

### `health` (Phase 1)

- **Routes**: `GET /api/health` — liveness probe
- **Controller**: `src/common/health/health.controller.ts`
- **Models**: none (dependency-free by design)
- **Note**: Deliberately has no DB/Redis dependency. Railway uses this to decide whether the process is alive; it must not fail when Postgres or Redis is merely degraded. A *readiness* probe (with dependency checks) is added in Phase 2 once a datasource exists.

### `config` (Phase 1)

- **Routes**: none (infrastructure)
- **Source**: `src/config/env.validation.ts`
- **Models**: `envSchema` (Zod) — 27 environment variables covering database, Redis, JWT, MSG91, Cashfree, Delhivery, Cloudflare R2, and business rules
- **Behaviour**: The application **refuses to boot** on missing or malformed configuration, reporting every invalid field at once rather than only the first. A missing Cashfree secret surfaces at startup, not at a customer's checkout.

### Pending

`auth`, `users`, `catalog`, `pdp`, `cart`, `checkout`, `orders`, `webhooks`, `wallet`, `returns`, `videos`, `admin`, `jobs` — not yet implemented (Phase 4).

**Excluded from this milestone**: `whatsapp-bot` — directory retained as boilerplate only, no logic to be written (user decision, 2026-08-10).

---

## 3. Security Measures Implemented

- **Boundary validation** — global `ZodValidationPipe`; every request payload is parsed and rejected at the edge before reaching a service or the database.
- **Fail-fast configuration** — invalid/missing secrets abort startup rather than surfacing as runtime failures mid-transaction.
- **Secret hygiene** — `JWT_SECRET` enforced at ≥32 characters; `.env` git-ignored; `.env.example` ships placeholders only.
- **HTTP hardening** — `helmet` applied globally.
- **Rate limiting at the origin** — `ThrottlerModule` (100 req/60s default) registered as a global guard. Applied at the origin *in addition to* Cloudflare's edge rate limiting, because direct-to-Railway requests bypass the edge entirely; the origin must not assume Cloudflare is in front of it.
- **Monetary precision** — all money handled in **paise as integers** (`FREE_DELIVERY_THRESHOLD_PAISE`, `REFERRAL_CREDIT_PAISE`), never floats.
- **Graceful shutdown** — `enableShutdownHooks()` for clean draining on Railway redeploys.
- **Production Swagger suppression** — API docs served only when `NODE_ENV !== 'production'`.

---

## 4. Security Measures Still Pending

These are mandated by `@GUARD`'s risk report and **must** ship with their respective phases:

| Risk | Severity | Lands in | Requirement |
| :--- | :--- | :--- | :--- |
| #1 Double referral payout | CRITICAL | Phase 2 + 4 | UNIQUE constraint on `(webhook_provider, webhook_event_id)`; wallet credit and webhook-record insert in **one DB transaction** |
| #2 Address-edit race | HIGH | Phase 4 | Order status re-checked inside the transaction (`SELECT ... FOR UPDATE`) before writing an address change |
| #3 Client-trusted pricing | HIGH | Phase 4 | Discounts, free-delivery, and referral credit recomputed server-side at order placement; client totals ignored |
| #4 N+1 queries | MEDIUM | Phase 2 + 4 | Explicit `leftJoinAndSelect` on catalog/PDP reads; composite indexes on `(category_id, price)`, `(brand_id)`, `(fabric_type)` |
| #5 Malformed `size_rules` | MEDIUM | Phase 4 | Admin-authored `size_rules` JSONB validated against a Zod schema on write |

Auth, authorization guards, and protected-route enforcement arrive with the `auth` module in Phase 4. **No route is authenticated yet** because no authenticated route exists yet.

---

## 5. Verification Evidence (Phase 1)

All re-verified on Node 24.12.0 after a clean `node_modules` reinstall:

| Check | Result |
| :--- | :--- |
| `npm install` | 772 packages, no `EBADENGINE` warning |
| `npx tsc --noEmit` | clean |
| `npx jest` | **18/18 passing**, 2 suites |
| `npm run build` | clean |
| `GET /api/health` | `200` `{"status":"ok","timestamp":"..."}` |
| `GET /docs` | `200` (Swagger UI) |
| `GET /docs-json` | valid OpenAPI `3.0.0` document |
| Invalid env (`JWT_SECRET=tooshort`, `DATABASE_URL=not-a-url`) | boot aborted, **both** failures named |

---

## 6. Notes for `@SEC`, `@QA`, and `@FE`

- **`@SEC` / `@QA`**: gates have not run and should not run yet — there is no business logic to audit. The meaningful audit surface arrives after Phase 4.
- **`@FE`**: the OpenAPI document at `/docs-json` is the contract to build against (ADR-005). It currently describes only the health endpoint. Do not begin client integration until Phase 4 modules are published here.
