# Final Project Context: Adorini E-Commerce Platform (v1.1 MVP)

> **Status**: OMNIPRESENT — Initialized for all MAS Agents
> **Version**: 1.0
> **Source of Truth**: Adorini TRD v1.1 & Product Spec V1
> **Theme Colors**: Peach, Light Brown

---

## 1. Product Statement

**Adorini** is a discovery-and-trust-led ethnic wear commerce platform for women aged 25–55 (price band ₹300–1,500, nominal sizes 40–48) selling kurtis, two-piece and three-piece suit sets, blouses, and petticoats across traditional prints and techniques (Kalankari, Ajrak, Batik, Aplik, Fancy).

### Core Priorities

1. **Trustworthy Sizing**: Dynamic fabric-specific size charts (stretch vs. rigid fabrics render different fit guidance for nominal sizes) to cut return rates. Fallback custom size enquiry form for out-of-range sizes.
2. **Trust Before Payment**: Distinguish admin-curated official product media (`ADMIN`) with an "Official Media" badge from buyer-submitted review photos/videos (`BUYER`). Structured fit-accuracy review tags (`runs small`, `true to size`, `runs large`).
3. **COD-First Checkout**: Intent verification step via MSG91 OTP prior to dispatch; delivery address editable until status is `Shipped`; ₹100 referral credit awarded only upon confirmed delivery (`Delivered`).

---

## 2. Core Approved Tech Stack

> **Versions finalized**: 2026-08-10, via @ARCH research pass. Two-vendor infra policy: **Railway (compute/DB) + Cloudflare (storage/edge) only — no AWS.**

| Layer | Technology | Version | Infrastructure / Host | Why |
| :--- | :--- | :--- | :--- | :--- |
| **Mobile App** | Flutter | (latest stable) | Cross-platform client | Single codebase for iOS and Android |
| **Backend Runtime** | Node.js | **24.x (Active LTS)** | Railway | LTS until Apr 2028; Node 26 not LTS until Oct 2026 — too fresh for a payments-adjacent MVP |
| **Backend Framework** | NestJS | **v11.1.28** | Railway | v12 is still a draft roadmap (Q3 2026, full ESM/Vitest/oxlint migration) — stay on stable 11.x, revisit after v12 GA + ecosystem catch-up |
| **ORM** | TypeORM | **1.1.0** | Railway | Resolved from prior "TypeORM/Prisma" ambiguity: TypeORM hit 1.0 in June 2026 (renewed maintenance, prior instability risk gone). QueryBuilder/raw-SQL escape hatch fits dynamic `size_rules` JSONB fit-logic better than Prisma's current JSONB querying |
| **Database** | PostgreSQL | **18.4** | Railway | JSONB for dynamic `size_rules` & brand/fabric attributes; v19 still in beta, not production-ready |
| **Cache & Sessions** | Redis (server 8.6.2, client **ioredis 5.4.x**) | — | Railway | Fast cart edits, session management, cached search/filter results, webhook idempotency keys. **Not ioredis 6** — TypeORM 1.1.0's peer range is `^5.0.4` and refuses to resolve against 6 (see backend ADR-006) |
| **Validation** | Zod **v4** + `nestjs-zod` ^5.5.0 | — | — | 14x faster string parsing vs v3. `nestjs-zod` supplies `ZodValidationPipe` + `createZodDto` so Zod is the *single* validation system — NestJS's class-validator `ValidationPipe` is deliberately unused (see backend ADR-007) |
| **Media Storage** | Cloudflare R2 (via `@aws-sdk/client-s3` v3) | — | Cloudflare | S3-compatible, **$0 egress** (vs ~$0.09/GB on S3) — decisive for a media-heavy PDP gallery + buyer review photos/video read pattern |
| **Edge / CDN / DNS / WAF** | Cloudflare (Proxied DNS, Cache Rules, WAF, Rate Limiting) | — | Cloudflare | Sits in front of Railway origin; caches cacheable GETs (catalog/product), edge rate-limits OTP endpoints, DDoS/bot protection. Cart/checkout/order routes explicitly `Cache-Control: no-store` |
| **Auth** | MSG91 OTP (direct REST API v5, no npm wrapper) + Google OAuth 2.0 | — | Custom JWT sessions | ~75-80% cheaper SMS in India than Firebase; free OAuth. No official/well-maintained MSG91 SDK exists — thin internal provider avoids unmaintained-dependency risk |
| **Payments** | Cashfree Gateway (`@cashfreepayments/cashfree-sdk`, ~5.1.0) | — | API integration | UPI + Card + COD reconciliation |
| **Logistics** | Delhivery Tracking API (direct REST, no SDK) | — | Webhooks | Live tracking webhook ingestion & dispatch status sync |

### Explicitly rejected for MVP

- **AWS (any service)** — R2 already beats S3 on egress economics for this traffic shape; adding AWS compute/CDN alongside Railway+Cloudflare would mean a second cloud bill and ops surface with no capability gap it fills. May reconsider **AWS SES only** later if transactional email volume grows past what's practical otherwise.
- **Cloudflare Tunnel / Zero Trust** — that pattern protects self-hosted origins (VPS/bare-metal); Railway is a managed PaaS that already terminates TLS, so it doesn't apply here. Revisit only if a component moves off Railway to self-hosted infra.
- **NestJS v12, PostgreSQL 19** — both pre-GA/beta as of this writing; do not adopt until stable.

---

## 3. Engineering & Domain Architecture Blueprint

### Bounded Domain Modules (`Adorini_Backend/src/modules/`)

- `auth`: Phone OTP generation/verify (MSG91), Google OAuth 2.0, JWT session persistence, MFA.
- `users`: User profiles, address editor (PIN, city, state, address line), gender, profile photo.
- `catalog`: Garment tabs, print/technique chips, price/size/brand filters, full-text search, "Shop by brand" rail, infinite scroll.
- `pdp`: Up to 5 media items gallery, dynamic fabric size chart banner, reviews with fit tags, custom-size enquiry form inbox.
- `cart`: Inline quantity/size/colour editor, Redis session cache + Postgres sync.
- `checkout`: Address validation, Cashfree gateway payment options (COD, UPI, Card), MSG91 COD verification OTP modal.
- `orders`: State machine: `Ordered` $\rightarrow$ `Pending_Verification` (COD) $\rightarrow$ `Confirmed` $\rightarrow$ `Shipped` $\rightarrow$ `Delivered` / `Cancelled`. Live Delhivery tracking API sync.
- `returns`: 3-day post-delivery return request evaluation & size-chart feedback loop.
- `wallet`: ₹100 referral reward async worker on `Delivered`, wallet balance, coupons, gift cards.
- `videos`: Reels-style video feed, video player, likes, comments, "Shop this look" product links.
- `webhooks`: Idempotent ingestion webhooks for Cashfree, Delhivery, and MSG91.
- `admin`: Product/variant CRUD, order overrides, video linking, coupon config, return reviews, enquiry inbox.
- `jobs`: Background scheduled tasks (referral payouts, restock alerts).

---

## 4. Design Guidelines & Theme

- **Primary Colors**: Peach (`#FFDAB9` / Warm Peach), Light Brown (`#C4A484` / Terracotta accent).
- **Typography**: Clean, readable sans-serif (Inter / Outfit) paired with elegant headers for ethnic wear.
- **Badges & Visual Indicators**:
  - `Official Media` badge on admin-uploaded images/videos.
  - Fit-accuracy review tags (`runs small`, `true to size`, `runs large`).
  - Free delivery progress bar (orders > ₹3,000 auto-qualify).
  - COD trust badges.

---

## 5. Critical Constraints & Guards

1. **Idempotency Guard**: Delhivery and Cashfree webhooks must verify idempotency keys to prevent duplicate referral payouts or duplicate order status transitions.
2. **Pre-Shipment Address Locks**: Address can be edited freely by the buyer until order status changes to `Shipped`.
3. **Microservices Extraction Threshold**: Hot paths (search, webhook ingestion) are kept inside NestJS for MVP; Go microservices extraction deferred until p99 search latency or webhook volume metrics require it.

---

## 6. Execution Status & Next Steps

> **Last updated**: 2026-08-10 · **Build strategy**: backend-first, Flutter integrates afterward against the generated OpenAPI contract (backend ADR-005).
> **Detailed backend tracking lives in `Adorini_Backend/.gsd/`** (SPEC, ROADMAP, STATE, DECISIONS). This section is the summary view.

### Pipeline Gate Status

| Gate | Agent | Status |
| :--- | :--- | :--- |
| Planning | `@PM` | ✅ PRD finalized |
| Pre-flight risk | `@GUARD` | ✅ Passed `approval_status: true` — 5 mitigations mandated, see `logs/risk_report.md` |
| Architecture | `@ARCH` | ✅ Approved, versions finalized |
| Design | `@DESIGN` | ✅ Design system approved |
| Build | `@BE` | 🔄 In progress — Phase 1 of 4 complete |
| Build | `@FE` | ⬜ Not started (follows backend) |
| Security | `@SEC` | ⬜ Gate not yet run |
| Ethics | `@ETHICS` | ⬜ Gate not yet run |
| Quality | `@QA` | ⬜ Gate not yet run |
| Deploy | `@OPS` | ⬜ Not started |

### Backend Build Progress (`@BE`)

- **Folder Structure**: Fully initialized (domain-driven modular NestJS backend & Clean Architecture Flutter frontend). `src/modules/users/` added; `src/modules/whatsapp-bot/` retained as boilerplate only — **no logic to be written**, deliberately not part of this milestone.
- **Phase 1 — Engine**: ✅ **COMPLETE & VERIFIED** on Node 24.12.0. Booting NestJS 11 app, strict TypeScript, Zod-validated env config that aborts startup on bad values, Swagger/OpenAPI contract generation, liveness endpoint, 18/18 tests passing.
- **Phase 2 — Data Model**: ⬜ Not started. Entities, migrations, seeds. Carries @GUARD Risks #1 (CRITICAL webhook idempotency constraint), #4 (catalog indexes), #6 (referral constraints).
- **Phase 3 — Integration Connectors**: ⬜ Not started. MSG91, Cashfree, Delhivery, R2, Redis, Google OAuth providers.
- **Phase 4 — Feature Modules**: ⬜ Not started. Carries @GUARD Risks #1, #2 (address-edit race), #3 (server-authoritative pricing), #5 (`size_rules` validation).

### Decisions Made During Build

Two stack decisions were forced by empirical failure during Phase 1 and are already reflected in Section 2 above:

- **ioredis pinned to 5.4.x, not 6.x** — TypeORM 1.1.0's peer range refuses to resolve against ioredis 6 (backend ADR-006).
- **Zod is the single validation system, via `nestjs-zod`** — NestJS's stock `ValidationPipe` requires class-validator, which would have meant two competing validation systems (backend ADR-007).

### Next Step

Execute Phase 2 — TypeORM entities, migrations, and seed data.
