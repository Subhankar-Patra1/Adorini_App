# Compliance Report

> **Status**: NOT YET RUN — intentionally deferred
> **Owner**: @ETHICS
> **Version**: 0
> **Last reviewed**: 2026-08-10

## Why This Gate Has Not Run

The `@ETHICS` gate audits data flows and personal-data handling. As of 2026-08-10 the backend has completed **Phase 1 (Engine) only** — no personal data is collected, stored, or transmitted, because no user, order, or review persistence exists yet.

**This gate runs after backend Phase 4 (Feature Modules) completes.**

### Known review surface for when this gate runs

Adorini collects a meaningful amount of personal data, so this gate is not a formality:

1. **Personal data inventory** — name, phone, email, gender, and full delivery address (PIN/city/state) are collected at mandatory profile setup. Justify each field against purpose limitation; `gender` in particular needs a stated purpose or should be optional.
2. **India DPDP Act 2023** — the primary applicable regime for an India-market app (alongside GDPR if any EU users). Consent, purpose limitation, and erasure rights.
3. **Right to erasure vs. financial records** — how account deletion interacts with order history and wallet/referral ledgers that may need retention.
4. **Third-party data sharing** — addresses and phone numbers flow to Delhivery (logistics) and MSG91 (SMS/OTP); payment data to Cashfree. Each needs a lawful basis and disclosure.
5. **Buyer-submitted review media** — photos/videos of identifiable people uploaded to R2; consent and takedown path.
6. **Bias analysis** — sizing guidance (nominal sizes 40–48) and any future recommendation/search ranking should be checked for exclusionary or body-shaming framing, given the product's stated "trustworthy sizing" promise.

## Feature
<!-- Feature under review -->

## Violations
<!-- 
- Issue:
  - Law:
  - Fix:
  - Fixed: false
-->

## Bias Analysis
<!-- Bias assessment results -->

## Approval Status
<!-- false — awaiting audit -->
