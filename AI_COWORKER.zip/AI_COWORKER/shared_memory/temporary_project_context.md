# Temporary Project Context: Adorini E-Commerce Platform

> **Status**: SUPERSEDED — consolidated into `final_project_context.md` (v1.1 MVP)
> **Owner**: @PM
> **Superseded on**: 2026-08-10
>
> ⚠️ **Historical record only.** This was the pre-planning snapshot. It is intentionally
> *not* kept in sync and now contains stale details (e.g. the ORM was still undecided
> here, and ioredis/Cloudflare-edge decisions came later). All agents must read
> `final_project_context.md` as the source of truth.

## Vision
**Adorini** is a discovery-and-trust-led ethnic wear commerce platform for women aged 25–55 (sizes 40–48, price band ₹300–1,500). Focuses on high-trust sizing (fabric-specific rules to reduce returns), trust indicators (badges for official media, structured reviews), and COD-first payment flow with verification guards.

## Core Architecture
- **Mobile**: Flutter client.
- **Backend**: NestJS (Node.js) on Railway.
- **Database**: PostgreSQL (JSONB columns for size rules) + Redis (cache, sessions, webhooks).
- **Storage**: Cloudflare R2 for official and buyer media assets.
- **Integrations**: Cashfree Payments, Delhivery Logistics, MSG91 Phone SMS/OTP.

## Key Constraints
- Indian logistics and checkout: COD is default, requiring robust SMS OTP confirmation before dispatch.
- Scalability: Modules should be isolated for eventual transition to Go microservices.
- Address adjustments: Must allow address changes up to the `Shipped` status.

## Security Requirements
- JWT auth tokens and secure refresh mechanisms.
- Verification of webhook signatures for Delhivery and Cashfree.
- Input validation (Zod/Class-validator) on all endpoints.

## Execution Notes
- Maintain domain modular folder architecture.
- Webhook processing must implement idempotency checks to prevent double actions.
