# Design System Specification: Adorini

> **Owner**: `@DESIGN` (UI/UX Designer)
> **Status**: APPROVED
> **Target Device**: Mobile-First (Flutter iOS & Android)

---

## 1. Color Palette

- **Primary Brand Color**: Peach (`#FFDAB9` / Soft Warm Peach)
- **Secondary / Accent Color**: Light Brown (`#C4A484` / Terracotta Earth Accent)
- **Background Color**: `#FFFDF9` (Off-white / Warm Canvas)
- **Surface / Card Color**: `#FFFFFF`
- **Text Primary**: `#2C221E` (Dark Brown Charcoal)
- **Text Secondary**: `#7A6E68` (Warm Muted Gray)
- **Success / Delivery**: `#2E7D32`
- **Error / Warning**: `#D32F2F`

---

## 2. Key Component UI Specifications

1. **Top Nav Bar**: Brand logo, garment tabs (`Kurti`, `Two piece`, `Three piece`, `Blouse`, `Petticoat`), Wishlist heart icon, Cart icon with badge.
2. **Search Bar**: Autocomplete suggestions dropdown triggering after 2+ characters.
3. **Filter Rail**: Garment types, Print/Technique chips (`Plain`, `Kalankari`, `Ajrak`, `Batik`, `Aplik`, `Fancy`), Price, Size (40-48), "Shop by Brand" rail (`sana`, `mg`, `mm`, `NAVRANGA`).
4. **Product Card**: High-res image, wishlist heart badge, strike-through original price vs discounted price, brand label, color swatches.
5. **Product Detail Gallery**: Swipeable up to 5 media items (videos/photos), with an **"Official Media"** badge overlay on admin-uploaded assets.
6. **Dynamic Fabric Size Selector**: Banner showing custom fit advice based on `STRETCH` vs `RIGID` fabric rules. Out-of-range enquiry modal trigger.
7. **Reviews List**: Star rating (1-5), fit-accuracy chip (`runs small`, `true to size`, `runs large`), buyer-submitted photo gallery.
8. **COD Checkout Modal**: Intent confirmation OTP input, line items inline editor, editable delivery address card before status is `Shipped`.
