# System Architecture Document: Adorini E-Commerce

> **Owner**: `@ARCH` (System Architect)
> **Status**: APPROVED
> **Backend Stack**: NestJS v11.1.28 (Node.js 24.x LTS) on Railway, TypeORM 1.1.0
> **Database**: PostgreSQL 18.4 (JSONB for `size_rules`) + Redis 8.6.2 (ioredis 5.4.x) on Railway
> **Frontend**: Flutter (iOS + Android)
> **Infra policy**: Two vendors only — Railway (compute/DB) + Cloudflare (storage/edge). No AWS.

---

## 1. System Topology

```text
                  ┌─────────────────────────────────┐
                  │   Flutter Mobile App (iOS/Android)│
                  └────────────────┬────────────────┘
                                   │ HTTPS
                                   ▼
                  ┌─────────────────────────────────┐
                  │  Cloudflare Edge (Proxied DNS,    │
                  │  Cache Rules, WAF, Rate Limiting) │
                  └────────────────┬────────────────┘
                                   │ HTTP / REST APIs
                                   ▼
                  ┌─────────────────────────────────┐
                  │  NestJS API Gateway (Railway)     │
                  │  Node 24.x · TypeORM 1.1.0        │
                  └────┬───────────┬───────────┬────┘
                       │           │           │
          ┌────────────▼──┐   ┌────▼─────┐  ┌──▼────────────┐
          │ PostgreSQL 18 │   │ Redis 8  │  │ Cloudflare R2 │
          │ (JSONB rules) │   │ (Cache)  │  │ (Media Storage,│
          │               │   │          │  │  $0 egress)   │
          └───────────────┘   └──────────┘  └───────────────┘
                                   │
                     ┌─────────────┼──────────────┐
                     ▼             ▼              ▼
                ┌──────────┐  ┌──────────┐  ┌───────────┐
                │ Cashfree │  │  MSG91   │  │ Delhivery │
                │ Payments │  │ OTP/SMS  │  │ Tracking  │
                │ (SDK)    │  │ (REST)   │  │ (REST)    │
                └──────────┘  └──────────┘  └───────────┘
```

Cart, checkout, and order routes bypass Cloudflare Cache Rules (`Cache-Control: no-store`) — only catalog/product GETs are edge-cached.

---

## 2. DB Schema Highlights

- **`users`**: `id`, `phone`, `email`, `first_name`, `last_name`, `gender`, `address_json`, `profile_status`, `created_at`.
- **`products`**: `id`, `title`, `description`, `fabric_type` (STRETCH | RIGID), `size_rules` (JSONB), `price`, `brand_id`, `category_id`.
- **`product_variants`**: `id`, `product_id`, `size`, `color`, `stock_quantity`, `sku`.
- **`media_assets`**: `id`, `product_id`, `url`, `media_origin` (`ADMIN` | `BUYER`), `media_type` (`IMAGE` | `VIDEO`).
- **`orders`**: `id`, `user_id`, `status` (`Ordered`, `Pending_Verification`, `Confirmed`, `Shipped`, `Delivered`, `Cancelled`), `payment_method`, `tracking_code`.
- **`reviews`**: `id`, `product_id`, `user_id`, `rating`, `comment`, `fit_accuracy` (`runs_small`, `true_to_size`, `runs_large`).
- **`size_enquiries`**: `id`, `user_id`, `product_id`, `contact_phone`, `requested_size_notes`, `status`.

---

## 3. Webhook Ingestion & Microservices Roadmap

- All webhooks (`Delhivery`, `Cashfree`, `MSG91`) process idempotency tokens via Redis before database updates.
- Microservices scaling plan: `search` and `webhook-ingestion` will be extracted into Go microservices when metrics require it.
