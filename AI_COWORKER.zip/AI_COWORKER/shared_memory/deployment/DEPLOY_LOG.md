# Deployment Log

> **Status**: NOT YET RUN — blocked by pipeline rule
> **Owner**: @OPS
> **Version**: 0
> **Last reviewed**: 2026-08-10

## Why This Has Not Run

`@OPS` is hard-blocked until `@QA` returns PASS. `@QA` has not run (see `tests/QA_REPORT.md`), because the backend has completed **Phase 1 of 4**. Nothing is deployable yet.

**Nothing has been deployed. No environment exists. No secrets have been provisioned on any host.**

## Target Infrastructure (decided, not yet provisioned)

Recorded here so `@OPS` inherits the decisions rather than re-litigating them — see `final_project_context.md` §2 and backend ADR-003:

- **Compute + Postgres 18.4 + Redis 8.6.2**: Railway
- **Media storage**: Cloudflare R2 ($0 egress)
- **Edge**: Cloudflare proxied DNS + Cache Rules + WAF + rate limiting, in front of the Railway origin
- **Explicitly rejected**: AWS (any service); Cloudflare Tunnel/Zero Trust (Railway is managed PaaS)
- **Runtime pin**: Node 24.12.0 (`.nvmrc`, `engines.node >=24.0.0`)

## Deployment Requirements Already Known

1. **Cache safety** — cart, checkout, and order routes must be excluded from Cloudflare Cache Rules (`Cache-Control: no-store`). An edge cache must never serve one user's cart to another.
2. **Edge rate limiting** — throttle `/auth/otp/*` at Cloudflare, in addition to the origin-level throttler already implemented.
3. **Secrets** — 27 env vars are required and validated at boot (see `Adorini_Backend/.env.example`). The app **refuses to start** if any are missing or malformed, so a misconfigured deploy fails fast rather than silently.
4. **Health check** — point Railway's probe at `GET /api/health` (dependency-free liveness). A readiness endpoint with DB/Redis checks arrives in Phase 2; do not wire the platform's restart policy to that one.
5. **Swagger** — automatically suppressed when `NODE_ENV=production`.
6. **Rollback + monitoring** — mandatory per `@OPS` rules; not yet designed.

## Environment
<!-- staging | production -->

## Deployment Steps
<!-- Ordered deployment steps -->

## CI/CD Pipeline
<!-- Pipeline configuration -->

## Monitoring
<!-- Monitoring and alerting setup -->

## Rollback Strategy
<!-- Rollback procedure -->

## Deployed URL
<!-- URL once deployed -->
