# Risk Report

> **Status**: COMPLETE
> **Owner**: @GUARD
> **Version**: 1
> **Reviewed**: PRD v1.1, ARCHITECTURE.md, final_project_context.md (2026-08-10 stack finalization)

## Risks

1. **Risk Type**: Race condition — double referral payout
   - **Severity**: CRITICAL
   - **Description**: Delhivery/webhook providers can and do redeliver the same event (network retries, at-least-once delivery). If the `Delivered` webhook triggers "check idempotency key in Redis, then credit ₹100 wallet in Postgres" as two separate steps, a redelivered webhook arriving in the gap between the check and the write double-credits the wallet. Architecture doc mentions idempotency but doesn't specify the mechanism.
   - **Impact**: Direct financial loss, compounds silently across every delivered order until caught.
   - **Mitigation**: Idempotency must be enforced at the **database layer**, not just checked in Redis first — e.g. a unique constraint on `(webhook_provider, webhook_event_id)` in a `processed_webhooks` table, written in the *same transaction* as the wallet credit. Redis can be a fast-path pre-check, but Postgres must be the source of truth that rejects duplicates.
   - **Required before**: `wallet` and `webhooks` modules (Phase 4).

2. **Risk Type**: Address-edit / shipment-transition race
   - **Severity**: HIGH
   - **Description**: "Address editable until `Shipped`" is a business rule, but if the address-edit endpoint and the Delhivery `Shipped` webhook aren't guarded by the same row lock, a user can submit an edit in the same instant the order transitions to `Shipped` — package ships to the old address while the DB shows the new one, or vice versa.
   - **Impact**: Wrong-address deliveries, customer trust damage (directly undercuts the "Trust Before Payment" core priority).
   - **Mitigation**: Address-edit endpoint must re-check order status inside a DB transaction (`SELECT ... FOR UPDATE` or equivalent) immediately before writing, not just at page-load time.
   - **Required before**: `orders` module (Phase 4).

3. **Risk Type**: Client-trusted pricing state
   - **Severity**: HIGH
   - **Description**: Free-delivery threshold (>₹3,000) and first-order 10% discount are described as "auto-applied" — if that logic runs client-side (Flutter) and checkout just accepts the final total, it's trivially tamperable.
   - **Impact**: Revenue leakage via manipulated totals.
   - **Mitigation**: Cart/checkout totals (discounts, free-delivery, referral credit) must be recomputed and authoritative server-side at order-placement time, never trusted from client payload.
   - **Required before**: `checkout` module (Phase 4). (Overlaps @SEC's domain — flagging here since it's a design-time decision, not just a code-review catch.)

4. **Risk Type**: N+1 queries on catalog/PDP
   - **Severity**: MEDIUM
   - **Description**: Catalog infinite-scroll (products → variants → media → brand) and PDP (product + up to 5 media + reviews + fit tags) are exactly the shape that produces N+1 under TypeORM's default lazy relations if built without explicit joins.
   - **Impact**: Latency cliff under real traffic; this is also the exact scenario the architecture doc names as the trigger for Go microservice extraction — better to avoid needing that extraction at all.
   - **Mitigation**: Use TypeORM QueryBuilder with explicit `leftJoinAndSelect` for catalog/PDP reads; add composite indexes on `(category_id, price)`, `(brand_id)`, `(fabric_type)` used by the filter rail.
   - **Required before**: `catalog` and `pdp` modules (Phase 4).

5. **Risk Type**: Malformed dynamic `size_rules` JSONB
   - **Severity**: MEDIUM
   - **Description**: `size_rules` is admin-authored JSONB with no schema enforcement mentioned. A malformed entry (missing a size, wrong key) silently breaks the fit-guidance banner for that product — directly undermines "Trustworthy Sizing," the PRD's #1 priority.
   - **Impact**: Wrong or missing fit guidance → the exact return-rate problem this feature exists to prevent.
   - **Mitigation**: Validate `size_rules` against a Zod schema on admin write (reject malformed input at the boundary), not just consume it as-is on read.
   - **Required before**: `admin` product CRUD (Phase 4).

6. **Risk Type**: Referral self-abuse
   - **Severity**: LOW (MVP-acceptable)
   - **Description**: No stated control preventing a user from referring a second account they also control to farm ₹100 credits.
   - **Impact**: Bounded financial leakage, not urgent for MVP scale.
   - **Mitigation**: At minimum, enforce `referrer_id != referee_id` and one-referral-per-phone-number at the DB level; defer device/IP fraud heuristics to post-MVP.
   - **Required before**: Not a blocker — track as backlog item for `wallet` module.

## Approval Status

**`true`** — no unmitigated CRITICAL risk remains blocking. Risk #1 is CRITICAL in *impact* but has a concrete, scoped mitigation (DB-level idempotency constraint) that must be written into the Phase 4 plan for `webhooks`/`wallet` as an explicit task with a `<verify>` step — not optional cleanup. Risks #2–#5 must be included as acceptance criteria in their respective Phase 4 module plans, not left implicit.
